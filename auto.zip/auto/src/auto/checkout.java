package auto;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;

public class checkout {
  @Test
 
	  {
	  driver.get("http://automationpractice.com");  
	  driver.findElement(By.linktext("sign in")).click();
	  driver.findElement(By.id("email_create")).sendKeys("sudeephari@gmail.com");	
	  driver.findElement(By.id("password")).sendkeys(abcdef);
	  driver.findElement(By.css("#submitAccount>span")).submit();
	  driver.findElement(By.css(".sfHover> .sf-with-ul ")).click();
	  driver.findElement(By.css("li:nth-child(2).subcategory-name")).click();
	  driver.findElement(By.css(".ajax_block_product:nth_child)(1).but...")).click();
	  driver.findElement(By.css(".button-medium:nth-child(2)>span")).click();
	  driver.findElement(By.css(".standard-checkout>span")).click();
	  driver.findElement(By.css(".button-nth-child(4)>span")).click();
	  driver.findElement(By.id("cgv")).click();
	  driver.findElement(By.css(".standard-checkout>span")).click();
	  driver.findElement(By.linktext("pay by check(order processing...")).click();
	  driver.findElement(By.css("#cart_navigation span")).click();
	  driver.findElement(By.linktext("Back to orders")).click();
	  driver.findElement(By.css("li:nth-child(2)>.btn>span")).click();
	  
	  
  }

  public void beforeTest() {
	  driver = new ChromeDriver();
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\SKarumathil\\Desktop\\java\\chromedriver.exe");
  }

 
  public void afterTest() {
	  driver.quit();
  }

}



