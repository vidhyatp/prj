package auto;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;

public class successreg { 
	 public static void main(String[] args)
	 { 
		@Test
	  
	  driver.get("http://automationpractice.com");  
	  driver.findElement(By.linktext("sign in")).click();
	  driver.findElement(By.id("email_create")).sendKeys("vidhyatp666@gmail.com");	
	  driver.findElement(By.css("#SubmitCreate")).submit();	
	  driver.findElement(By.id("id_gender2")).click();
	  driver.findElement(By.id("customer_firstname")).sendkeys(Vidhya);
	  driver.findElement(By.id("customer_lastname")).sendkeys(Sudeep);
	  driver.findElement(By.id("password")).sendkeys(abcdef);
	  driver.findElement(By.id("address1")).sendkeys(adsdfhh);
	  driver.findElement(By.id("city")).sendkeys(Arizona);
	  driver.findElement(By.id("postalcode")).sendkeys(00000);
	  driver.findElement(By.id("phone_mobile")).sendkeys(7899765);
	  driver.findElement(By.id("address_alias")).sendkeys(yghjhjhjj);
	  driver.findElement(By.css("#submitAccount>span")).submit();	
	  
	  
	  Select drpstate = new Select(driver.findElement(By.id("id_state")));
		drpstate.selectByVisibleText("Arizona");
		
}

public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SKarumathil\\Desktop\\java\\chromedriver.exe");
		    WebDriver driver = new ChromeDriver();
}


public void afterTest() {
			driver.quit();	
}




}


